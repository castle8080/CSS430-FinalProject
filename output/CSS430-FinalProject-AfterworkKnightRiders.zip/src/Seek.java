
/**
 * Seek related constants.
 */
public class Seek {
    public final static int SET = 0;
    public final static int CUR = 1;
    public final static int END = 2;
}
